1)
a. Shane Rodricks
b. 2343774
c. rodricks@chapman.edu
d. CPSC 231-04
e. WAR Assignment
f. This is my own work, I did not copy anyone else's work.

2) Main.java, Card.java, Cards.java, Player.java, Deck.java, CardsInPlay.java, Game.java, WarResolver.java, StatTracker.java
3) For 100 games: Average battles per game: 85.42
Average wars per game: 6.04
Average double wars per game: 0.36
Max battles: 450
Min battles: 9

Max wars: 37
Min wars: 0
4) I worked on this assignment by myself.
5) javac *.java, Main.java
